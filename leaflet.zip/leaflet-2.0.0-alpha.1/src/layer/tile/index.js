export {GridLayer} from './GridLayer.js';
import {TileLayer} from './TileLayer.js';
import {TileLayerWMS} from './TileLayer.WMS.js';
TileLayer.WMS = TileLayerWMS;
export {TileLayer};
