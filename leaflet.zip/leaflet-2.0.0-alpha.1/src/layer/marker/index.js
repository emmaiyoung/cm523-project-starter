import {Icon} from './Icon.js';
import {IconDefault} from './Icon.Default.js';
Icon.Default = IconDefault;
export {Icon};

export {DivIcon} from './DivIcon.js';
export {Marker} from './Marker.js';
